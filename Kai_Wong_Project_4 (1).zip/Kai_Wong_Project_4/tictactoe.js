//Kai Wong 11/19 Project 3
function set(idvalue) { 
	// Find the button clicked by id
	var buttonclicked = document.getElementById(idvalue);
	if(buttonclicked.value ==""||buttonclicked.value==null){
		

	// Complete the function from here
	// Add a statement to find out who is the current user, “X” or “O” by reading paragraph id “currentplayer” in tictactoe.html
	var xory = document.getElementById("currentplayer").innerHTML;
	// Add a statement to let the value of buttonclicked be the current user
	buttonclicked.value = xory;
	buttonclicked.innerHTML = xory;
	// Add a statement to let the innerHTML of buttonclicked be the current user (to display “X” or “O” on the buttonclicked) 

	//Add a statement to change player
	check_win();
	
    }
	else{
		alert("You cannot go here!");
	}
}

function changeplayer(){
	// Add a statement to find out who is the current user, “X” or “O” by reading paragraph id “result” in tictactoe.html, and save it in a variable called player
	var player = document.getElementById("currentplayer").innerHTML;
	
	if(player == "X")
	{
	// change the current user to “O” if the current user is “X”
	document.getElementById("currentplayer").innerHTML = "O";
	}
	else
	{
	// Add a statement to change the current user to “X” if the current user is “O”
	document.getElementById("currentplayer").innerHTML = "X";
	}
	
}

function check_win(){
	// add a statement to find out who is the current player, “X” or “O” by reading the contents of paragraph (id “currentplayer”) in tictactoe.html, and save it in a variable called player
	var player = document.getElementById("currentplayer").innerHTML;
	
	if (document.getElementById(0).value == document.getElementById(1).value && document.getElementById(1).value == document.getElementById(2).value && document.getElementById(2).value == document.getElementById(3).value && document.getElementById(3).value == document.getElementById(4).value && document.getElementById(1).value == player)
	{
		alert("You win! The winner is "+player);
	}
	else if (document.getElementById(5).value == document.getElementById(6).value && document.getElementById(6).value == document.getElementById(7).value && document.getElementById(7).value == document.getElementById(8).value && document.getElementById(8).value == document.getElementById(9).value && document.getElementById(6).value == player)
	{
		alert("You win! The winner is "+player);
	}
	else if (document.getElementById(10).value == document.getElementById(11).value && document.getElementById(11).value == document.getElementById(12).value && document.getElementById(12).value == document.getElementById(13).value && document.getElementById(13).value == document.getElementById(14).value && document.getElementById(10).value == player)
	{
		alert("You win! The winner is "+player);
	}
	else if (document.getElementById(15).value == document.getElementById(16).value && document.getElementById(16).value == document.getElementById(17).value && document.getElementById(17).value == document.getElementById(18).value && document.getElementById(18).value == document.getElementById(19).value && document.getElementById(15).value == player)
	{
		alert("You win! The winner is "+player);
	}
	else if (document.getElementById(20).value == document.getElementById(21).value && document.getElementById(21).value == document.getElementById(22).value && document.getElementById(22).value == document.getElementById(23).value && document.getElementById(23).value == document.getElementById(24).value && document.getElementById(20).value == player)
	{
		alert("You win! The winner is "+player);
	}
	else if (document.getElementById(0).value == document.getElementById(5).value && document.getElementById(5).value == document.getElementById(10).value && document.getElementById(10).value == document.getElementById(15).value && document.getElementById(15).value == document.getElementById(20).value && document.getElementById(0).value == player)
	{
		alert("You win! The winner is "+player);
	}
	else if (document.getElementById(1).value == document.getElementById(6).value && document.getElementById(6).value == document.getElementById(11).value && document.getElementById(11).value == document.getElementById(16).value && document.getElementById(16).value == document.getElementById(21).value && document.getElementById(1).value == player)
	{
		alert("You win! The winner is "+player);
	}
	else if (document.getElementById(2).value == document.getElementById(7).value && document.getElementById(7).value == document.getElementById(12).value && document.getElementById(12).value == document.getElementById(17).value && document.getElementById(17).value == document.getElementById(22).value && document.getElementById(2).value == player)
	{
		alert("You win! The winner is "+player);
	}
	else if (document.getElementById(3).value == document.getElementById(8).value && document.getElementById(8).value == document.getElementById(13).value && document.getElementById(13).value == document.getElementById(18).value && document.getElementById(18).value == document.getElementById(23).value && document.getElementById(3).value == player)
	{
		alert("You win! The winner is "+player);
	}
	else if (document.getElementById(4).value == document.getElementById(9).value && document.getElementById(9).value == document.getElementById(14).value && document.getElementById(14).value == document.getElementById(19).value && document.getElementById(19).value == document.getElementById(24).value && document.getElementById(4).value == player)
	{
		alert("You win! The winner is "+player);
	}
	else if (document.getElementById(0).value == document.getElementById(6).value && document.getElementById(6).value == document.getElementById(12).value && document.getElementById(12).value == document.getElementById(18).value && document.getElementById(18).value == document.getElementById(24).value && document.getElementById(0).value == player)
	{
		alert("You win! The winner is "+player);
	}
	else if (document.getElementById(4).value == document.getElementById(8).value && document.getElementById(8).value == document.getElementById(12).value && document.getElementById(12).value == document.getElementById(16).value && document.getElementById(16).value == document.getElementById(20).value && document.getElementById(4).value == player)
	{
		alert("You win! The winner is "+player);
	}
	else{
		changeplayer(); //nobody wins, change player
	}
}
